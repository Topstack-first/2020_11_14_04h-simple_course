﻿namespace University.Web.Areas.Identity.Pages.Account
{
    using Microsoft.AspNetCore.Mvc.RazorPages;

    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}

