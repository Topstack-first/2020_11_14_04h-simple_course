﻿namespace VinylC.Common.Constants
{
    public class Roles
    {
        public const string AdminRole = "Admin";
    }
}
