﻿namespace University.Common.Mapping
{
    public interface IMapFrom<TModel>
        where TModel : class
    {
    }
}
