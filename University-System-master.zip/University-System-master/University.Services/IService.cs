﻿namespace University.Services
{
    public interface IService
    {
    }
}
