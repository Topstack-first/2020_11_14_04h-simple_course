﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace ACourse.Controllers
{
    public class CourseEvaluationController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult JavaEvaluate()
        {
            return View();
        }
        public IActionResult CPlusEvaluate()
        {
            return View();
        }
        public IActionResult CSharpEvaluate()
        {
            return View();
        }
    }
}
