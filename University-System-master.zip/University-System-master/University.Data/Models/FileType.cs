﻿namespace University.Data.Models
{
    public enum FileType
    {
        Zip = 0,
        Pdf = 1,
        Pptx = 2,
    }
}
