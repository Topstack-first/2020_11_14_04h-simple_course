﻿namespace University.Web.Models.Courses
{
    public class CourseBasicViewModel
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
