﻿NProgress.start();
NProgress.done();