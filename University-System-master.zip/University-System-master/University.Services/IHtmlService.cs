﻿namespace University.Services
{
    public interface IHtmlService
    {
        string Sanitize(string htmlContent);
    }
}
