﻿namespace University.Common.Mapping
{
    public interface IMapTo<TModel>
        where TModel : class
    {
    }
}
