﻿namespace University.Data.Models
{
    public enum Status
    {
        Completed = 0,
        Pending = 1
    }
}
