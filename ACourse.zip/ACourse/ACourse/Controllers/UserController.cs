﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ACourse.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore;
using System.Web;
using Microsoft.AspNetCore.Http;

namespace ACourse.Controllers
{
    public class UserController : Controller
    {
       // private DB_Entities _db = new DB_Entities();

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult UserManage()
        {
            return View();
        }
        public IActionResult LoginPage()
        {
            return View();
        }
        public IActionResult RegisterPage()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(string username, string password)
        {
            /*
            if (ModelState.IsValid)
            {
                var f_password = password;
                var data = _db.Users.Where(s => s.UserName.Equals(username) && s.Password.Equals(f_password)).ToList();
                if (data.Count() > 0)
                {
                    //add session
                    HttpContext.Session.SetString("UserName", data.FirstOrDefault().UserName);
                    HttpContext.Session.SetString("Password", data.FirstOrDefault().Password);
                    HttpContext.Session.SetInt32("idUser", data.FirstOrDefault().idUser);
                    return RedirectToAction("Index");
                }
                else
                {
                    ViewBag.error = "Login failed";
                    return RedirectToAction("Login");
                }
            }
            */
            return View();
        }


        //Logout
        public ActionResult Logout()
        {

            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
        //POST: Register
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(User _user)
        {
            /*
            if (ModelState.IsValid)
            {
                var check = _db.Users.FirstOrDefault(s => s.UserName == _user.UserName);
                if (check == null)
                {
                    _user.Password = _user.Password;
                    _db.Configuration.ValidateOnSaveEnabled = false;
                    _db.Users.Add(_user);
                    _db.SaveChanges();
                    return RedirectToAction("Index","Home");
                }
                else
                {
                    ViewBag.error = "UserName already exists";
                    return View();
                }


            }
            */
            return View();
        }
    }
}
