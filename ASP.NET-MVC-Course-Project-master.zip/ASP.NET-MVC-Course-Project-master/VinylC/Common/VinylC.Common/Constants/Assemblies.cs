﻿namespace VinylC.Common.Constants
{
    public class Assemblies
    {
        public const string DataServices = "VinylC.Services.Data";

        public const string MVCProject = "VinylC.Web.MVC";
    }
}
