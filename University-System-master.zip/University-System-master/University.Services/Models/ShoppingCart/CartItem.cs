﻿namespace University.Services.Models.ShoppingCart
{
    public class CartItem
    {
        public int CourseId { get; set; }
    }
}
