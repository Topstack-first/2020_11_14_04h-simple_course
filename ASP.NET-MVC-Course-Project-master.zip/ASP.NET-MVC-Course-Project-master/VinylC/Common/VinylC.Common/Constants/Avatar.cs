﻿namespace VinylC.Common.Constants
{
    public class Avatar
    {
        public const string DefaultAvatar = "http://www.veryicon.com/icon/256/Media/AutoRate%20-%20Vinyl/Vinyl%20Blue.png";

        public const string AdminAvatar = "http://www.veryicon.com/icon/png/Media/Metalic%20CD/Gold%20CD.png";
    }
}
