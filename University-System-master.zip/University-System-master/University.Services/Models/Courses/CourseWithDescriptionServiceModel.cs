﻿namespace University.Services.Models.Courses
{
    public class CourseWithDescriptionServiceModel : CourseServiceModel
    {
        public string Description { get; set; }
    }
}
