﻿using System;

namespace adlcp_v1P3
{
    public class Class1
    {
    }
}
