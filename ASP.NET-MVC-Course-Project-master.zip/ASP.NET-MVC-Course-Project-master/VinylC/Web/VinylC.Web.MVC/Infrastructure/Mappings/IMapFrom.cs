﻿namespace VinylC.Web.MVC.Infrastructure.Mappings
{
    public interface IMapFrom<T>
    {
    }
}