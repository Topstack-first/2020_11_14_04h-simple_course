﻿
using Microsoft.EntityFrameworkCore;
using ACourse.Models;

namespace ACourse.Models
{
    public class DB_Entities : DbContext
    {
        public DB_Entities(DbContextOptions<DB_Entities> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
    }
}