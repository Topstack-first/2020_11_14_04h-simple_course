﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace ACourse.Controllers
{
    public class CourseBrowsingController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult JavaCourse()
        {
            return View();
        }
        public IActionResult CPlusCourse()
        {
            return View();
        }
        public IActionResult CSharpCourse()
        {
            return View();
        }
    }
}
