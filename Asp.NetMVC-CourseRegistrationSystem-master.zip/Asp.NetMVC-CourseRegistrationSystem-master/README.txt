This project demonstrates a simple course registration Asp.Net MVC application.  
It demonstrates ability to log on with input validation, maintain session state, and uses SQL for persistence of student preferences.  
To get started, make sure you edit the Web.config connection string to point to a valid SQL server, then run SQLPreparationScript.sql against that server.  
The included solution should build against VS2012 and higher