﻿namespace University.Services
{
    public interface ISingletonService
    {
    }
}
